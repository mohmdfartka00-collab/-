// Universal Netlify Function supporting both Lambda format and modern fetch format
// CLOUDFLARE_ADMIN_TOKEN is kept strictly server-side and never exposed to the client.

const ADMIN_EMAIL = 'mohmdfartka00@gmail.com';
const WORKER_URL = process.env.CLOUDFLARE_WORKER_URL || 'https://divine-firefly-7938.mohmdfartka00.workers.dev';
const ADMIN_TOKEN = process.env.CLOUDFLARE_ADMIN_TOKEN || '';

function parseJwtPayload(token: string): any {
  try {
    const base64Url = token.split('.')[1];
    if (!base64Url) return null;
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = Buffer.from(base64, 'base64').toString('utf-8');
    return JSON.parse(jsonPayload);
  } catch {
    return null;
  }
}

function verifyAdminFromHeader(authHeader: string | null | undefined): boolean {
  if (!authHeader || !authHeader.startsWith('Bearer ')) return false;
  const token = authHeader.split('Bearer ')[1];
  const payload = parseJwtPayload(token);
  if (!payload || !payload.email) return false;
  return payload.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase();
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Content-Type': 'application/json',
};

// Universal handler compatible with all Netlify environments
export const handler = async (arg1: any, arg2?: any) => {
  // If invoked as standard Web Request (Netlify Functions V2)
  if (arg1 instanceof Request || (arg1 && typeof arg1.arrayBuffer === 'function')) {
    const req = arg1 as Request;
    const url = new URL(req.url);
    const path = url.pathname.replace(/^\/\.netlify\/functions\/api/, '').replace(/^\/api/, '');

    if (req.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    if (path === '/health' || path === '') {
      return new Response(JSON.stringify({ status: 'ok', netlify: true }), {
        status: 200,
        headers: corsHeaders,
      });
    }

    const authHeader = req.headers.get('authorization');
    if (!verifyAdminFromHeader(authHeader)) {
      return new Response(JSON.stringify({ error: 'عذراً، فقط المسؤول يمكنه تنفيذ هذا الإجراء' }), {
        status: 403,
        headers: corsHeaders,
      });
    }

    if (path === '/storage/upload' && req.method === 'PUT') {
      const name = url.searchParams.get('name');
      if (!name) {
        return new Response(JSON.stringify({ error: 'اسم الملف مفقود' }), { status: 400, headers: corsHeaders });
      }

      try {
        const fileBuffer = await req.arrayBuffer();
        const cfRes = await fetch(`${WORKER_URL}/upload?name=${encodeURIComponent(name)}`, {
          method: 'PUT',
          headers: {
            'Content-Type': req.headers.get('content-type') || 'application/octet-stream',
            ...(ADMIN_TOKEN ? { 'Authorization': `Bearer ${ADMIN_TOKEN}` } : {}),
          },
          body: fileBuffer,
        });
        const text = await cfRes.text();
        return new Response(text, { status: cfRes.status, headers: corsHeaders });
      } catch (err: any) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    if (path === '/storage/file' && req.method === 'DELETE') {
      const name = url.searchParams.get('name');
      if (!name) {
        return new Response(JSON.stringify({ error: 'اسم الملف مفقود' }), { status: 400, headers: corsHeaders });
      }
      try {
        const cfRes = await fetch(`${WORKER_URL}/file?name=${encodeURIComponent(name)}`, {
          method: 'DELETE',
          headers: ADMIN_TOKEN ? { 'Authorization': `Bearer ${ADMIN_TOKEN}` } : {},
        });
        const text = await cfRes.text();
        return new Response(text, { status: cfRes.status, headers: corsHeaders });
      } catch (err: any) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders });
      }
    }

    return new Response(JSON.stringify({ error: 'المسار غير موجود' }), { status: 404, headers: corsHeaders });
  }

  // Otherwise, invoked as standard AWS Lambda Event (Netlify Functions V1 - Default)
  const event = arg1 || {};
  const httpMethod = event.httpMethod || 'GET';
  const rawPath = event.path || '';
  const path = rawPath.replace(/^\/\.netlify\/functions\/api/, '').replace(/^\/api/, '');
  const headers = event.headers || {};
  const query = event.queryStringParameters || {};

  if (httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders, body: '' };
  }

  if (path === '/health' || path === '') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ status: 'ok', netlify: true }),
    };
  }

  const authHeader = headers['authorization'] || headers['Authorization'];
  if (!verifyAdminFromHeader(authHeader)) {
    return {
      statusCode: 403,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'عذراً، فقط المسؤول يمكنه تنفيذ هذا الإجراء' }),
    };
  }

  if (path === '/storage/upload' && httpMethod === 'PUT') {
    const name = query.name;
    if (!name) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'اسم الملف مفقود' }) };
    }

    try {
      let bodyData: any = event.body;
      if (event.isBase64Encoded) {
        bodyData = Buffer.from(event.body, 'base64');
      }

      const cfRes = await fetch(`${WORKER_URL}/upload?name=${encodeURIComponent(name)}`, {
        method: 'PUT',
        headers: {
          'Content-Type': headers['content-type'] || headers['Content-Type'] || 'application/octet-stream',
          ...(ADMIN_TOKEN ? { 'Authorization': `Bearer ${ADMIN_TOKEN}` } : {}),
        },
        body: bodyData,
      });

      const resText = await cfRes.text();
      return {
        statusCode: cfRes.status,
        headers: corsHeaders,
        body: resText,
      };
    } catch (err: any) {
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({ error: err.message }),
      };
    }
  }

  if (path === '/storage/file' && httpMethod === 'DELETE') {
    const name = query.name;
    if (!name) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'اسم الملف مفقود' }) };
    }

    try {
      const cfRes = await fetch(`${WORKER_URL}/file?name=${encodeURIComponent(name)}`, {
        method: 'DELETE',
        headers: ADMIN_TOKEN ? { 'Authorization': `Bearer ${ADMIN_TOKEN}` } : {},
      });

      const resText = await cfRes.text();
      return {
        statusCode: cfRes.status,
        headers: corsHeaders,
        body: resText,
      };
    } catch (err: any) {
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({ error: err.message }),
      };
    }
  }

  return {
    statusCode: 404,
    headers: corsHeaders,
    body: JSON.stringify({ error: 'المسار غير موجود' }),
  };
};

export default handler;
