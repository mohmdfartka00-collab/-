import { StrictMode, Component, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  override state: ErrorBoundaryState = { hasError: false, error: null };

  constructor(props: ErrorBoundaryProps) {
    super(props);
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: any) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-6 text-center font-sans" dir="rtl">
          <div className="bg-slate-800/80 border border-slate-700 p-8 rounded-2xl max-w-md w-full shadow-2xl">
            <h1 className="text-2xl font-bold text-red-400 mb-4">حدث خطأ غير متوقع</h1>
            <p className="text-slate-300 text-sm mb-6">
              {this.state.error?.message || 'تعذر تحميل واجهة التطبيق بشكل صحيح.'}
            </p>
            <button
              onClick={() => window.location.reload()}
              className="w-full py-3 px-6 bg-blue-600 hover:bg-blue-500 rounded-xl font-medium transition cursor-pointer"
            >
              إعادة تحميل الصفحة
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
