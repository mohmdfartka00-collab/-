import { collection, addDoc, query, onSnapshot, orderBy, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import { db } from './firebase';

export type FileCategory = 'app' | 'video' | 'image' | 'file';

export interface AppData {
  id?: string;
  name: string;
  version?: string;
  description: string;
  icon?: string;
  downloadUrl: string;
  createdAt: any;
  ownerId: string;
  category: FileCategory;
  fileSize?: string;
  mimeType?: string;
  storageKey?: string;
  iconStorageKey?: string;
}

export const addApp = async (app: Omit<AppData, 'id' | 'createdAt'>) => {
  return await addDoc(collection(db, 'apps'), {
    ...app,
    createdAt: new Date(),
  });
};

export const deleteApp = async (id: string) => {
  return await deleteDoc(doc(db, 'apps', id));
};

export const updateApp = async (id: string, updates: Partial<AppData>) => {
  return await updateDoc(doc(db, 'apps', id), updates);
};

export const subscribeToApps = (callback: (apps: AppData[]) => void, category?: FileCategory) => {
  try {
    let q = query(collection(db, 'apps'), orderBy('createdAt', 'desc'));
    return onSnapshot(
      q, 
      (snapshot) => {
        const apps = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AppData));
        if (category) {
          callback(apps.filter(app => app.category === category));
        } else {
          callback(apps);
        }
      },
      (error) => {
        console.warn('Firestore onSnapshot error:', error);
        callback([]);
      }
    );
  } catch (err) {
    console.warn('Firestore query setup error:', err);
    callback([]);
    return () => {};
  }
};
