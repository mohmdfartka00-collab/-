/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import { Upload, LogIn, LogOut, Download, X, Chrome, Search, Filter, Smartphone, Film, Image as ImageIcon, File as FileIcon, MoreHorizontal, Share2, Check, Copy, Trash2, Edit, HardDrive, Cloud } from 'lucide-react';
import { auth, googleProvider } from './firebase';
import { onAuthStateChanged, signInWithEmailAndPassword, signOut, createUserWithEmailAndPassword, signInWithPopup, signInWithRedirect, getRedirectResult } from 'firebase/auth';
import { subscribeToApps, AppData, addApp, FileCategory, deleteApp, updateApp } from './db';

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [apps, setApps] = useState<AppData[]>([]);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<FileCategory | 'all'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Upload Form State
  const [uploadName, setUploadName] = useState('');
  const [uploadVersion, setUploadVersion] = useState('');
  const [uploadDescription, setUploadDescription] = useState('');
  const [uploadCategory, setUploadCategory] = useState<FileCategory>('app');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadIcon, setUploadIcon] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  // Edit State
  const [editingApp, setEditingApp] = useState<AppData | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editName, setEditName] = useState('');
  const [editVersion, setEditVersion] = useState('');
  const [editDescription, setEditDescription] = useState('');

  const ADMIN_EMAIL = 'mohmdfartka00@gmail.com';
  const isAdmin = user?.email ? user.email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase() : false;

  useEffect(() => {
    getRedirectResult(auth).catch((err) => console.log("Redirect result error:", err));
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const unsubscribe = subscribeToApps((fetchedApps) => {
      setApps(fetchedApps);
    });
    return () => unsubscribe();
  }, []);

  // Calculate total used storage
  const totalUsedMB = useMemo(() => {
    return apps.reduce((acc, app) => {
      if (!app.fileSize) return acc;
      const num = parseFloat(app.fileSize);
      return acc + (isNaN(num) ? 0 : num);
    }, 0);
  }, [apps]);

  const totalCapacityMB = 10240; // 10 GB
  const storagePercentage = Math.min(100, Math.round((totalUsedMB / totalCapacityMB) * 100));

  const filteredApps = useMemo(() => {
    return apps.filter(app => {
      const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            app.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = activeCategory === 'all' || app.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [apps, searchQuery, activeCategory]);

  const handleLogin = async () => {
    try {
      if (isRegistering) {
        await createUserWithEmailAndPassword(auth, loginEmail, loginPassword);
      } else {
        await signInWithEmailAndPassword(auth, loginEmail, loginPassword);
      }
      setIsLoginModalOpen(false);
      setLoginEmail('');
      setLoginPassword('');
    } catch (error: any) {
      alert("خطأ: " + error.message);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      setIsLoginModalOpen(false);
    } catch (error: any) {
      console.warn("Popup failed, trying redirect:", error);
      try {
        await signInWithRedirect(auth, googleProvider);
      } catch (redirectError: any) {
        alert("خطأ في تسجيل الدخول عبر جوجل: " + (error.message || redirectError.message));
      }
    }
  };

  const handleLogout = () => {
    signOut(auth);
  };

  const fileToDataUrl = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const WORKER_URL = 'https://divine-firefly-7938.mohmdfartka00.workers.dev';

  const uploadToR2 = async (file: File, prefix: string = ''): Promise<string> => {
    const timestamp = Date.now();
    const safeFileName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
    const storageKey = `${prefix}${timestamp}-${safeFileName}`;
    
    // Get Firebase ID Token for authentication with the server proxy
    const idToken = await auth.currentUser?.getIdToken();
    if (!idToken) throw new Error('يجب تسجيل الدخول بحساب المسؤول أولاً');

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      const proxyUrl = `/api/storage/upload?name=${encodeURIComponent(storageKey)}`;

      xhr.open('PUT', proxyUrl, true);
      xhr.setRequestHeader('Authorization', `Bearer ${idToken}`);
      xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');

      if (prefix === '') {
        xhr.upload.onprogress = (event) => {
          if (event.lengthComputable) {
            const percentComplete = Math.round((event.loaded / event.total) * 100);
            setUploadProgress(percentComplete);
          }
        };
      }

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(storageKey);
        } else {
          try {
            const err = JSON.parse(xhr.responseText);
            reject(new Error(err.error || `فشل الرفع: ${xhr.statusText}`));
          } catch {
            reject(new Error(`فشل الرفع: ${xhr.statusText}`));
          }
        }
      };

      xhr.onerror = () => reject(new Error('فشل الاتصال بخادم الرفع'));
      xhr.send(file);
    });
  };

  const handleUpload = async () => {
    if (!isAdmin) {
      alert("عذراً، فقط المسؤول (mohmdfartka00@gmail.com) يمكنه رفع الملفات");
      return;
    }

    if (!uploadName || !uploadFile) {
      alert("يرجى إكمال البيانات الأساسية (الاسم والملف)");
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      // 1. Upload the main file
      const storageKey = await uploadToR2(uploadFile);
      const downloadUrl = `${WORKER_URL}/file?name=${encodeURIComponent(storageKey)}`;

      // 2. Upload icon if provided, otherwise handle image thumbnail
      let iconUrl = undefined;
      let iconStorageKey = undefined;
      if (uploadIcon) {
        iconStorageKey = await uploadToR2(uploadIcon, 'icon-');
        iconUrl = `${WORKER_URL}/file?name=${encodeURIComponent(iconStorageKey)}`;
      } else if (uploadCategory === 'image' && uploadFile.type.startsWith('image/')) {
        iconUrl = downloadUrl;
      }

      // 3. Save to Firestore
      await addApp({
        name: uploadName,
        version: uploadCategory === 'app' ? uploadVersion : undefined,
        description: uploadDescription,
        category: uploadCategory,
        downloadUrl: downloadUrl,
        storageKey: storageKey,
        icon: iconUrl,
        iconStorageKey: iconStorageKey,
        ownerId: user?.uid || 'anonymous',
        fileSize: (uploadFile.size / (1024 * 1024)).toFixed(2) + ' MB',
        mimeType: uploadFile.type,
      });

      alert("تم الرفع والحفظ بنجاح!");
      setIsUploadModalOpen(false);
      resetUploadForm();
    } catch (error: any) {
      console.error(error);
      alert("خطأ في الرفع: " + (error.message || "حدث خطأ غير معروف"));
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const handleDelete = async (id: string) => {
    const app = apps.find(a => a.id === id);
    if (!app) return;

    if (!isAdmin) {
      alert("ليس لديك صلاحية حذف الملفات");
      return;
    }

    if (confirm("هل أنت متأكد من حذف هذا الملف نهائياً؟")) {
      try {
        const idToken = await auth.currentUser?.getIdToken();
        if (!idToken) throw new Error('يجب تسجيل الدخول أولاً');

        const deleteFileFromStorage = async (key: string) => {
          const proxyDeleteUrl = `/api/storage/file?name=${encodeURIComponent(key)}`;
          const response = await fetch(proxyDeleteUrl, { 
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${idToken}` }
          });
          if (!response.ok) {
            console.error('Failed to delete file from R2', await response.text());
          }
        };

        if (app.storageKey) {
          await deleteFileFromStorage(app.storageKey).catch(e => console.error('Delete file error:', e));
        }

        if (app.iconStorageKey) {
          await deleteFileFromStorage(app.iconStorageKey).catch(e => console.error('Delete icon error:', e));
        }
        
        await deleteApp(id);
        alert("تم الحذف بنجاح وتحديث مساحة التخزين");
      } catch (err: any) {
        alert("خطأ أثناء الحذف: " + err.message);
      }
    }
  };

  const openEditModal = (app: AppData) => {
    setEditingApp(app);
    setEditName(app.name);
    setEditVersion(app.version || '');
    setEditDescription(app.description);
    setIsEditModalOpen(true);
  };

  const handleUpdate = async () => {
    if (!editingApp || !editingApp.id) return;
    try {
      await updateApp(editingApp.id, {
        name: editName,
        version: editVersion || undefined,
        description: editDescription,
      });
      alert("تم التعديل بنجاح");
      setIsEditModalOpen(false);
      setEditingApp(null);
    } catch (err: any) {
      alert("خطأ أثناء التعديل: " + err.message);
    }
  };

  const handleCopyLink = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const resetUploadForm = () => {
    setUploadName('');
    setUploadVersion('');
    setUploadDescription('');
    setUploadFile(null);
    setUploadIcon(null);
    setUploadCategory('app');
  };

  const categories = [
    { id: 'all', name: 'الكل', icon: MoreHorizontal },
    { id: 'app', name: 'تطبيقات', icon: Smartphone },
    { id: 'video', name: 'فيديوهات', icon: Film },
    { id: 'image', name: 'صور', icon: ImageIcon },
    { id: 'file', name: 'ملفات أخرى', icon: FileIcon },
  ];

  const getIconForCategory = (cat: string) => {
    switch (cat) {
      case 'app': return <Smartphone size={32} className="text-[#7b3fb3]" />;
      case 'video': return <Film size={32} className="text-red-500" />;
      case 'image': return <ImageIcon size={32} className="text-blue-500" />;
      default: return <FileIcon size={32} className="text-gray-500" />;
    }
  };


  return (
    <div className="min-h-screen bg-[#f4f2f7] text-[#29252f] dir-rtl">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/92 backdrop-blur-md border-b border-[#ddd8e2] px-[6%] py-4 flex justify-between items-center flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="text-[23px] font-bold text-[#7b3fb3]">تطبيقاتى</div>
          {isAdmin && (
            <span className="bg-[#7b3fb3]/10 text-[#7b3fb3] text-[10px] font-bold px-2 py-0.5 rounded-full border border-[#7b3fb3]/20">
              وضع المدير
            </span>
          )}
        </div>
        
        {/* Search Bar */}
        <div className="flex-1 max-w-md relative mx-4 order-3 md:order-2 w-full md:w-auto">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="ابحث عن تطبيق، فيديو، أو صورة..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#f1eef4] border-none rounded-full py-2.5 pr-10 pl-4 outline-none focus:ring-2 focus:ring-[#7b3fb3]/20 transition-all text-sm"
          />
        </div>

        <div className="flex items-center gap-2.5 order-2 md:order-3">
          {!user ? (
            <button 
              onClick={() => setIsLoginModalOpen(true)}
              className="bg-[#eeeaf2] text-[#633493] px-[18px] py-[11px] rounded-[12px] text-sm font-medium hover:-translate-y-0.5 transition-all duration-200"
            >
              تسجيل الدخول
            </button>
          ) : (
            <button 
              onClick={handleLogout}
              className="bg-[#eeeaf2] text-[#633493] px-[18px] py-[11px] rounded-[12px] text-sm font-medium hover:-translate-y-0.5 transition-all duration-200"
            >
              تسجيل الخروج
            </button>
          )}
          {isAdmin && (
            <button 
              onClick={() => setIsUploadModalOpen(true)}
              className="bg-[#7b3fb3] text-white px-[18px] py-[11px] rounded-[12px] text-sm font-medium hover:-translate-y-0.5 transition-all duration-200 flex items-center gap-2 shadow-lg shadow-[#7b3fb3]/20"
            >
              <Upload size={18} />
              رفع ملف
            </button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-[1200px] w-[88%] mx-auto mt-[45px] pb-12">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-[#7b3fb3] to-[#a875ca] text-white rounded-[25px] p-[45px] px-[30px] mb-[35px] shadow-[0_15px_40px_rgba(91,48,125,0.18)] flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs font-bold mb-4">
              <Cloud size={14} />
              مساحة تخزين سحابية خاصة (10 GB)
            </div>
            <h1 className="text-[34px] font-bold mb-3 text-center md:text-right">كل ملفاتك في مكان واحد</h1>
            <p className="opacity-90 text-base text-center md:text-right">ارفع تطبيقاتك وفيديوهاتك وصورك، وانشرها بروابط تحميل مباشرة مع إدارة كاملة وتعديل وحذف.</p>
          </div>

          <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-5 min-w-[240px] text-center">
            <div className="flex items-center justify-between text-xs font-bold mb-2 opacity-90">
              <span>المساحة المستخدمة</span>
              <span>{totalUsedMB.toFixed(1)} MB / 10 GB</span>
            </div>
            <div className="w-full bg-black/20 h-3 rounded-full overflow-hidden mb-3">
              <div 
                className="bg-white h-full transition-all duration-500 rounded-full" 
                style={{ width: `${Math.max(2, storagePercentage)}%` }}
              ></div>
            </div>
            <div className="text-[11px] opacity-80">{apps.length} ملف مخزن في مساحتك الخاصة</div>
          </div>
        </section>

        {/* Categories Bar */}
        <div className="flex gap-3 mb-8 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={`flex items-center gap-2 px-6 py-3 rounded-full whitespace-nowrap transition-all ${
                activeCategory === cat.id 
                ? 'bg-[#7b3fb3] text-white shadow-md' 
                : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-100'
              }`}
            >
              <cat.icon size={18} />
              <span className="font-medium">{cat.name}</span>
            </button>
          ))}
        </div>

        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">الملفات المرفوعة ({filteredApps.length})</h2>
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Filter size={16} />
            <span>ترتيب حسب الأحدث</span>
          </div>
        </div>

        {/* Apps Grid */}
        <div className="grid grid-cols-[repeat(auto-fill,minmax(280px,1fr))] gap-6">
          {filteredApps.length === 0 ? (
            <div className="col-span-full text-center py-[80px] bg-white rounded-[25px] text-[#77717d] border border-dashed border-[#ddd8e2] flex flex-col items-center gap-4">
              <FileIcon size={48} className="opacity-20" />
              <div className="text-lg">لا توجد ملفات في هذا القسم حالياً</div>
              {isAdmin && (
                <button onClick={() => setIsUploadModalOpen(true)} className="text-[#7b3fb3] font-bold">
                  ارفع أول ملف الآن
                </button>
              )}
            </div>
          ) : (
            filteredApps.map((app) => (
              <div key={app.id} className="group bg-white border border-[#e0dce4] rounded-[24px] p-6 shadow-[0_10px_30px_rgba(40,30,50,0.05)] hover:-translate-y-2 hover:shadow-[0_20px_45px_rgba(123,63,179,0.15)] transition-all duration-300 relative overflow-hidden flex flex-col justify-between">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[#7b3fb3]/10 to-transparent rounded-bl-[120px] pointer-events-none transition-all group-hover:scale-125 group-hover:opacity-30"></div>
                
                <div>
                  {/* Card Header with External Icon / Thumbnail */}
                  <div className="flex justify-between items-start mb-4">
                    <div className="relative">
                      {app.icon ? (
                        <div className="w-16 h-16 rounded-2xl p-1 bg-gradient-to-tr from-[#7b3fb3] to-[#a875ca] shadow-lg shadow-[#7b3fb3]/20 flex items-center justify-center overflow-hidden group-hover:rotate-3 transition-transform">
                          <img src={app.icon} alt={app.name} className="w-full h-full object-cover rounded-xl bg-white" />
                        </div>
                      ) : (
                        <div className="w-16 h-16 rounded-2xl bg-[#f4f1f8] border border-[#e8e2ee] flex items-center justify-center shadow-sm group-hover:rotate-3 transition-transform">
                          {getIconForCategory(app.category)}
                        </div>
                      )}
                      <span className="absolute -bottom-1 -right-1 bg-white text-[10px] font-bold px-1.5 py-0.5 rounded-full border border-gray-100 shadow-xs uppercase">
                        {app.category === 'app' ? 'APK' : app.category === 'video' ? 'MP4' : app.category === 'image' ? 'IMG' : 'FILE'}
                      </span>
                    </div>

                    <div className="flex flex-col items-end gap-1.5">
                      {app.fileSize && (
                        <span className="text-[11px] font-bold bg-[#f4f1f8] text-[#7b3fb3] px-2.5 py-1 rounded-full border border-[#e8e2ee]">
                          {app.fileSize}
                        </span>
                      )}
                      <span className="text-[10px] font-medium text-gray-400">
                        {app.category === 'app' ? 'تطبيق رسمي' : app.category === 'video' ? 'فيديو عالي الدقة' : app.category === 'image' ? 'صورة عالية الجودة' : 'ملف سحابي'}
                      </span>
                    </div>
                  </div>

                  <div className="text-[19px] font-bold mb-1 truncate text-gray-900 group-hover:text-[#7b3fb3] transition-colors">{app.name}</div>
                  {app.version && (
                    <div className="text-[#7b3fb3] text-[12px] font-bold mb-3 flex items-center gap-1.5 bg-[#7b3fb3]/5 w-fit px-2.5 py-1 rounded-lg">
                      <Smartphone size={13} />
                      إصدار {app.version}
                    </div>
                  )}
                  <div className="text-[#66616b] text-[14px] leading-[1.6] line-clamp-2 min-h-[44px] mb-6">{app.description}</div>
                </div>

                <div>
                  <div className="flex gap-2 mb-3">
                    <button 
                      onClick={() => window.open(app.downloadUrl, '_blank')}
                      className="flex-[3] bg-[#7b3fb3] text-white py-3.5 rounded-2xl hover:bg-[#633493] shadow-lg shadow-[#7b3fb3]/15 active:scale-95 transition-all flex items-center justify-center gap-2 font-bold text-sm"
                    >
                      <Download size={18} />
                      تنزيل مباشر
                    </button>
                    <button 
                      onClick={() => handleCopyLink(app.downloadUrl, app.id!)}
                      className={`flex-1 flex items-center justify-center rounded-2xl border transition-all ${
                        copiedId === app.id 
                        ? 'bg-green-50 border-green-200 text-green-600' 
                        : 'bg-white border-gray-100 text-gray-400 hover:border-gray-300 hover:text-[#7b3fb3]'
                      }`}
                      title="نسخ الرابط"
                    >
                      {copiedId === app.id ? <Check size={18} /> : <Share2 size={18} />}
                    </button>
                  </div>

                  {isAdmin && (
                    <div className="flex gap-2 pt-3 border-t border-gray-100 mt-2">
                      <button
                        onClick={() => openEditModal(app)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-bold text-blue-600 bg-blue-50/60 hover:bg-blue-100 rounded-xl transition-all"
                      >
                        <Edit size={14} />
                        تعديل
                      </button>
                      <button
                        onClick={() => handleDelete(app.id!)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-2 text-xs font-bold text-red-600 bg-red-50/60 hover:bg-red-100 rounded-xl transition-all"
                      >
                        <Trash2 size={14} />
                        حذف
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </main>

      {/* Edit Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-[1000] bg-black/60 flex items-center justify-center p-5 backdrop-blur-sm">
          <div className="bg-white w-full max-w-[450px] rounded-[28px] p-8 shadow-2xl animate-in fade-in zoom-in duration-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-[#633493]">تعديل بيانات الملف</h2>
              <button onClick={() => setIsEditModalOpen(false)} className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100 transition-all">
                <X size={24} />
              </button>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">اسم الملف / التطبيق</label>
                <input 
                  type="text" 
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full border border-gray-100 bg-[#f8f6fa] rounded-[16px] p-3.5 outline-none focus:ring-2 focus:ring-[#7b3fb3]/10 focus:bg-white transition-all font-medium"
                />
              </div>

              {editingApp?.category === 'app' && (
                <div>
                  <label className="block text-xs font-bold text-gray-600 mb-1">رقم الإصدار (اختياري)</label>
                  <input 
                    type="text" 
                    value={editVersion}
                    onChange={(e) => setEditVersion(e.target.value)}
                    className="w-full border border-gray-100 bg-[#f8f6fa] rounded-[16px] p-3.5 outline-none focus:ring-2 focus:ring-[#7b3fb3]/10 focus:bg-white transition-all font-medium"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">الوصف</label>
                <textarea 
                  rows={3}
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full border border-gray-100 bg-[#f8f6fa] rounded-[16px] p-3.5 outline-none focus:ring-2 focus:ring-[#7b3fb3]/10 focus:bg-white transition-all font-medium resize-none"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button onClick={() => setIsEditModalOpen(false)} className="flex-1 bg-gray-100 text-gray-500 py-3.5 rounded-[16px] hover:bg-gray-200 transition-all font-bold">إلغاء</button>
              <button onClick={handleUpdate} className="flex-1 bg-[#7b3fb3] text-white py-3.5 rounded-[16px] hover:bg-[#633493] transition-all font-bold shadow-lg shadow-[#7b3fb3]/20">حفظ التعديلات</button>
            </div>
          </div>
        </div>
      )}

      {/* Login Modal */}
      {isLoginModalOpen && (
        <div className="fixed inset-0 z-[1000] bg-black/60 flex items-center justify-center p-5 backdrop-blur-sm">
          <div className="bg-white w-full max-w-[450px] rounded-[28px] p-8 shadow-2xl animate-in fade-in zoom-in duration-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-[#633493]">{isRegistering ? 'انضم إلينا' : 'مرحباً بعودتك'}</h2>
              <button onClick={() => setIsLoginModalOpen(false)} className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100 transition-all">
                <X size={24} />
              </button>
            </div>

            <button 
              onClick={handleGoogleLogin}
              className="w-full flex items-center justify-center gap-3 border border-gray-200 bg-white text-gray-700 py-3.5 rounded-[16px] mb-6 hover:bg-gray-50 hover:border-gray-300 transition-all font-bold shadow-sm"
            >
              <Chrome className="text-[#4285F4]" size={22} />
              تسجيل الدخول عبر جوجل
            </button>

            <div className="flex items-center gap-3 mb-6">
              <div className="flex-1 h-[1px] bg-gray-100"></div>
              <span className="text-xs text-gray-400 font-medium">أو استخدم البريد</span>
              <div className="flex-1 h-[1px] bg-gray-100"></div>
            </div>

            <div className="space-y-3.5 mb-6">
              <input 
                type="email" 
                placeholder="البريد الإلكتروني"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full border border-gray-100 bg-[#f8f6fa] rounded-[16px] p-4 outline-none focus:ring-2 focus:ring-[#7b3fb3]/10 focus:bg-white transition-all"
              />
              <input 
                type="password" 
                placeholder="كلمة المرور"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full border border-gray-100 bg-[#f8f6fa] rounded-[16px] p-4 outline-none focus:ring-2 focus:ring-[#7b3fb3]/10 focus:bg-white transition-all"
              />
            </div>

            <div className="text-center mb-6">
              <button 
                onClick={() => setIsRegistering(!isRegistering)}
                className="text-sm font-bold text-[#7b3fb3] hover:underline"
              >
                {isRegistering ? 'لديك حساب بالفعل؟ سجل دخولك' : 'ليس لديك حساب؟ أنشئ حساباً جديداً'}
              </button>
            </div>

            <div className="flex gap-3">
              <button onClick={() => setIsLoginModalOpen(false)} className="flex-1 bg-gray-100 text-gray-500 py-4 rounded-[16px] hover:bg-gray-200 transition-all font-bold">إلغاء</button>
              <button onClick={handleLogin} className="flex-1 bg-[#7b3fb3] text-white py-4 rounded-[16px] hover:bg-[#633493] transition-all font-bold shadow-lg shadow-[#7b3fb3]/20">
                {isRegistering ? 'إنشاء حساب' : 'دخول'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload Modal */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-[1000] bg-black/60 flex items-center justify-center p-5 backdrop-blur-sm">
          <div className="bg-white w-full max-w-[500px] rounded-[28px] p-8 shadow-2xl animate-in fade-in zoom-in duration-200 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-[#633493]">لوحة رفع الملفات (للمسؤول)</h2>
              <button onClick={() => setIsUploadModalOpen(false)} className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-gray-100 transition-all">
                <X size={24} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-600 mb-2 mr-1">نوع الملف</label>
                <div className="grid grid-cols-4 gap-2">
                  {categories.slice(1).map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setUploadCategory(cat.id as any)}
                      className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl border transition-all ${
                        uploadCategory === cat.id 
                        ? 'bg-[#7b3fb3] text-white border-[#7b3fb3] shadow-md shadow-[#7b3fb3]/20' 
                        : 'bg-white text-gray-500 border-gray-100 hover:border-gray-300'
                      }`}
                    >
                      <cat.icon size={20} />
                      <span className="text-[10px] font-bold">{cat.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <input 
                type="text" 
                placeholder="اسم الملف"
                value={uploadName}
                onChange={(e) => setUploadName(e.target.value)}
                className="w-full border border-gray-100 bg-[#f8f6fa] rounded-[16px] p-4 outline-none focus:ring-2 focus:ring-[#7b3fb3]/10 focus:bg-white transition-all"
              />
              
              {uploadCategory === 'app' && (
                <input 
                  type="text" 
                  placeholder="رقم الإصدار (مثال: 1.0.2)"
                  value={uploadVersion}
                  onChange={(e) => setUploadVersion(e.target.value)}
                  className="w-full border border-gray-100 bg-[#f8f6fa] rounded-[16px] p-4 outline-none focus:ring-2 focus:ring-[#7b3fb3]/10 focus:bg-white transition-all"
                />
              )}

              <textarea 
                placeholder="وصف الملف..."
                value={uploadDescription}
                onChange={(e) => setUploadDescription(e.target.value)}
                className="w-full border border-gray-100 bg-[#f8f6fa] rounded-[16px] p-4 outline-none focus:ring-2 focus:ring-[#7b3fb3]/10 focus:bg-white transition-all h-[100px] resize-none"
              />
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 mb-2 mr-1">أيقونة (اختياري)</label>
                  <label className="block w-full border-2 border-dashed border-gray-200 bg-gray-50 rounded-2xl p-4 text-center cursor-pointer hover:bg-gray-100 transition-all overflow-hidden truncate">
                    <ImageIcon size={20} className="mx-auto mb-1 text-gray-400" />
                    <span className="text-[10px] text-gray-500">{uploadIcon ? uploadIcon.name : 'اختر صورة'}</span>
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => setUploadIcon(e.target.files?.[0] || null)} />
                  </label>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 mb-2 mr-1">الملف المطلوب</label>
                  <label className="block w-full border-2 border-dashed border-[#7b3fb3]/20 bg-[#7b3fb3]/5 rounded-2xl p-4 text-center cursor-pointer hover:bg-[#7b3fb3]/10 transition-all overflow-hidden truncate">
                    <FileIcon size={20} className="mx-auto mb-1 text-[#7b3fb3]" />
                    <span className="text-[10px] font-bold text-[#7b3fb3]">{uploadFile ? uploadFile.name : 'اختر ملف'}</span>
                    <input 
                      type="file" 
                      accept={uploadCategory === 'app' ? '.apk,.aab' : uploadCategory === 'video' ? 'video/*' : uploadCategory === 'image' ? 'image/*' : '*'} 
                      className="hidden" 
                      onChange={(e) => setUploadFile(e.target.files?.[0] || null)} 
                    />
                  </label>
                </div>
              </div>
            </div>

            {isUploading && (
              <div className="mt-6 bg-[#f8f6fa] border border-[#e0dce4] rounded-2xl p-4">
                <div className="flex justify-between items-center text-xs font-bold text-[#7b3fb3] mb-2">
                  <span>جاري رفع الملف إلى المساحة السحابية (10 GB)...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <div className="w-full bg-gray-200 h-3 rounded-full overflow-hidden">
                  <div 
                    className="bg-[#7b3fb3] h-full transition-all duration-300 rounded-full"
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
              </div>
            )}

            <div className="flex gap-3 mt-8">
              <button onClick={() => setIsUploadModalOpen(false)} disabled={isUploading} className="flex-1 bg-gray-100 text-gray-500 py-4 rounded-[16px] hover:bg-gray-200 transition-all font-bold disabled:opacity-50">إلغاء</button>
              <button 
                onClick={handleUpload} 
                disabled={isUploading}
                className="flex-1 bg-[#7b3fb3] text-white py-4 rounded-[16px] hover:bg-[#633493] transition-all font-bold shadow-lg shadow-[#7b3fb3]/20 disabled:opacity-50"
              >
                {isUploading ? (
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    جاري الرفع ({uploadProgress}%)
                  </div>
                ) : 'تأكيد الرفع'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
