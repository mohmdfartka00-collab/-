import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyA6TYxrLwf73ZAZV1KBUvbgparhWAnfo90",
  authDomain: "solid-team-qf4nj.firebaseapp.com",
  projectId: "solid-team-qf4nj",
  storageBucket: "solid-team-qf4nj.firebasestorage.app",
  messagingSenderId: "824867507619",
  appId: "1:824867507619:web:f733739eff41e83399de16"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
